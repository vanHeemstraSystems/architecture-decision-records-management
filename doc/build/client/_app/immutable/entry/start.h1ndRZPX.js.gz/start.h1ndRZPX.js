import{e as s}from"../chunks/LR2r_SSS.js";import{D as t}from"../chunks/DkP4RNrQ.js";export{t as load_css,s as start};
