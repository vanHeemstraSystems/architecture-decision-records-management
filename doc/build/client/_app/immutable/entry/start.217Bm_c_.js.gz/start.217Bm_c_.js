import{e as s}from"../chunks/nLxPELqZ.js";import{D as t}from"../chunks/7yTeWAjM.js";export{t as load_css,s as start};
