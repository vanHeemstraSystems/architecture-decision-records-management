import{e as s}from"../chunks/BmVwe_yo.js";import{D as t}from"../chunks/a-pri1DD.js";export{t as load_css,s as start};
