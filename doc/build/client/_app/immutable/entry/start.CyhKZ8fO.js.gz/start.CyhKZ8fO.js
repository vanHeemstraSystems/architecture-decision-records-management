import{e as s}from"../chunks/DCzd7V-E.js";import{D as t}from"../chunks/DbJa8Qya.js";export{t as load_css,s as start};
