import{e as s}from"../chunks/B_9opMpx.js";import{D as t}from"../chunks/B4sxF3Ap.js";export{t as load_css,s as start};
