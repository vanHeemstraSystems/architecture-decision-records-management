import{e as s}from"../chunks/Dve_LQZY.js";import{D as t}from"../chunks/CWn4Sf8z.js";export{t as load_css,s as start};
