import{e as s}from"../chunks/DHpvB_Aq.js";import{D as t}from"../chunks/CNJFelbY.js";export{t as load_css,s as start};
