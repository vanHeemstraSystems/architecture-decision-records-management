import{e as s}from"../chunks/ZKp_BRVo.js";import{D as t}from"../chunks/BBPc-KeX.js";export{t as load_css,s as start};
