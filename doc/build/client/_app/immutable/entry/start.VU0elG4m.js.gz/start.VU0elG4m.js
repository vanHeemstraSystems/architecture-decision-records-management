import{e as s}from"../chunks/DcQN_Vps.js";import{D as t}from"../chunks/Okmxp4pe.js";export{t as load_css,s as start};
