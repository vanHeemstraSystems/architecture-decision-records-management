import"./BBPc-KeX.js";import{q as r}from"./B54AC-aF.js";const o=r("ngsbie/search");export{o as s};
