import"./Okmxp4pe.js";import{q as r}from"./B1HuJVw1.js";const o=r("ngsbie/search");export{o as s};
