import"./CRD3T6-p.js";import{q as r}from"./BWsEkm3C.js";const o=r("ngsbie/search");export{o as s};
