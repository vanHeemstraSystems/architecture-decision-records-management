import"./B4sxF3Ap.js";import{q as r}from"./DkxS8YdD.js";const o=r("ngsbie/search");export{o as s};
