import"./a-pri1DD.js";import{q as r}from"./DZw9P0EH.js";const o=r("ngsbie/search");export{o as s};
