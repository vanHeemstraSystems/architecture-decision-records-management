import"./DkP4RNrQ.js";import{q as r}from"./BQpdSTaK.js";const o=r("ngsbie/search");export{o as s};
